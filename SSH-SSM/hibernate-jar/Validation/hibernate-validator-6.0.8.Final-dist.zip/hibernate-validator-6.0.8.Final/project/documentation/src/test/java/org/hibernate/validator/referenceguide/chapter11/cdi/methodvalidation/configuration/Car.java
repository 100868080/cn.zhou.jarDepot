package org.hibernate.validator.referenceguide.chapter11.cdi.methodvalidation.configuration;

public class Car {
}
