package org.hibernate.validator.referenceguide.chapter03.crossparameter.constrainttarget;

public class Car {
}
