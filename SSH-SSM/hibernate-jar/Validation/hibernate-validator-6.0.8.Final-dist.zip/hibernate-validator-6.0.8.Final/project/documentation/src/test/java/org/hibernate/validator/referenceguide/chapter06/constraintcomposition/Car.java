package org.hibernate.validator.referenceguide.chapter06.constraintcomposition;

public class Car {

	@ValidLicensePlate
	private String licensePlate;

	//...
}
